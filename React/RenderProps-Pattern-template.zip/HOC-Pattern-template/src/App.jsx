import React from 'react'

const App = () => {
  return (
    <div>
      <form>
        <input type="text" placeholder='text' />
        <button type='submit'>Submit</button>
      </form>
    </div>
  )
}

export default App