import { NavLink } from "react-router-dom";

const Navbar = () => {

    return (
        <nav>
            <NavLink to="/">Home |</NavLink>
            <NavLink to="/dashboard">  Dashboard |</NavLink>
            <NavLink  to="/login">  LogIn  |</NavLink>
            <NavLink  to="/registro">  Registro  </NavLink>
        </nav>
    );
};

export default Navbar;
