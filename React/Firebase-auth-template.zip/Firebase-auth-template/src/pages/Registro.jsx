import React from 'react'

const Registro = () => {
  return (
    <div>
      <h1>Registro</h1> 
    </div>
  )
}

export default Registro