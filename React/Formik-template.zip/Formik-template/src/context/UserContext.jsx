import React, { createContext, useEffect, useState } from 'react'

// Exportamos el auth en config/firebase
import {auth} from "../config/firebase" 
import { onAuthStateChanged } from 'firebase/auth'

export const UserContext = createContext()


const UserProvider = ({children}) => {
  const [user, setUser] = useState(false)

  useEffect ( () => {
    const unsuscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        // console.log(user)
        setUser(user)
      }
    });
    return unsuscribe
  }, []) 

  // Vemos que a podemos entrar en la ruta protegida.


  // Firebase tardará unos instantes en devolvernos el usuarios...
  if (user ===  null) return <p>Loading ...</p>

  return (
    <UserContext.Provider value ={{user, setUser}}>
        {children}
    </UserContext.Provider>
  )
}

export default UserProvider


// Ahora si el usuario está activo lo vamos a mandar al dashboard. Vamos a implementarlo en el login.