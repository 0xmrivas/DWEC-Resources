import { useContext } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { UserContext } from "../context/UserContext";
import { logOut } from "../config/firebase";

const Navbar = () => {
    const {user, setUser} = useContext(UserContext)

    const handleLogout = async () => {
        await logOut();
        setUser(false)
      };

    return (
            <nav>
                <NavLink to="/">Home |</NavLink>
                {user && <NavLink to="/dashboard">  Dashboard |</NavLink>}
                {
                    user ? (
                        <NavLink onClick={handleLogout}>  Cerrar sesión</NavLink>
                    ) : (
                        <>
                            <NavLink to="/login">  LogIn |</NavLink>
                            <NavLink to="/register">  Register</NavLink>
                        </>
                    )
                }
            </nav>

    );
};

export default Navbar;




// <nav>
//     <NavLink to="/">Home |</NavLink>
//     {user && <NavLink to="/dashboard">Dashboard |</NavLink>}
//     {user ? (
//         <NavLink onClick={handleLogout}>Cerrar sesión |</NavLink>
//     ) : (
//         <GuestLinks />
//     )}
// </nav>

// const GuestLinks = () => (
//     <>
//         <NavLink to="/login">LogIn |</NavLink>
//         <NavLink to="/register">Register</NavLink>
//     </>
// );
